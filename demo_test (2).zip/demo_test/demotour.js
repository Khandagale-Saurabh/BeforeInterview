let image_resource_box = './images/resource_close_toggle.png'
let resource_box_all_opion = "./images/resources.png"
let ask_lead='./images/ask_a_lead.png'
let asklead_dialogbox='./images/ask_a_lead_box.png';
let follw_up_link='./images/follow_up.png'
let follow_up_dialog='./images/follow_updialogbox.png'

// ============================
// let transfer_button_link1="./images/transfer_button.png";

window.addEventListener('load', () => {
   
    //    ===================
    // Trasnferlink( transfer_button_link);
    let maindiv = document.getElementById('maindiv')
    // document.getElementById('oip').style.borderStyle='dotted';
    console.log('on load');
    let card = document.createElement('div')
    // let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id', 'lamo')
    card.setAttribute('id', 'close_button_resourse')



    let img1 = document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src = image_resource_box;
    card.appendChild(img1);

    let card_body = document.createElement('div');
    card_body.setAttribute('id', 'visible')
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p = document.createElement('p');
    p.textContent = 'Click';
    aTag.addEventListener('click', function () {
        console.log('Inside aTag');
        card.classList.remove('highlight')
        card.classList.remove('card')
          document.getElementById('close_button_resourse').style.display='none'
        callInvoke(resource_box_all_opion)
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)

    document.body.append(maindiv)


})


function callInvoke(imgtobesend)
{
    console.log('callInvoke');
    let card=document.createElement('div')
    // let id=document.createAttribute('id','lamo')
     card.setAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
card.setAttribute('id','resources')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
        card_body.setAttribute('id','disable1')
        card.classList.remove('card')
        card.classList.remove('highlight');
        asklead(ask_lead);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}



function asklead(imgtobesend)
{
    console.log('callInvoke');
    let card=document.createElement('div')
    // let id=document.createAttribute('id','lamo')
     card.setAttribute('id','lamo')
    card.classList.add('card')

    card.classList.add('highlight')
        card.setAttribute('id','resources')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
      

       card_body.setAttribute('id','disable1')
       card.setAttribute('id','disable1')
       card.classList.remove('highlight')
        card.classList.remove('card')
    functionasklead_dialogbox(asklead_dialogbox);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}




function functionasklead_dialogbox(imgtobesend)
{
    
    console.log('asklead dialogbox');
    let card=document.createElement('div')
    // let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources')
    card.classList.add('highlight')
    card.setAttribute('id','ask_lead')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
        card_body.classList.add('disable1')
        card.classList.remove('highlight')
        card.classList.remove('card')
        document.getElementById('ask_lead').style.display='none'
     followuo_linek( follw_up_link);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}



function followuo_linek(imgtobesend)
{
    
    console.log('Followup  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','follow_up')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('follow_up').style.display='none'
        follow_up_dialogfunction( follow_up_dialog);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let ask_assistance_link="./images/as_a_assistance.png";


function follow_up_dialogfunction(imgtobesend)
{
    
    console.log('Followup  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','follow_up11')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        ask_assistance( ask_assistance_link);
     document.getElementById('follow_up11').style.display='none'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}



let ask_assistancefollowup='./images/ask_assistancefollowup.png'
function ask_assistance(imgtobesend)
{
    
    console.log('AskAssistance  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','ask_a_assistance')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in ask_a_assistance';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside ask_a_assistancelink');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('ask_a_assistance').style.display='none'
        ask_assistancefollowupfun( ask_assistancefollowup);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let pastcontact_link='./images/past_contact_link.png'
function ask_assistancefollowupfun(imgtobesend)
{
    
    console.log('ask_assistancefollowup  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','followup_dialogbox')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        pastcontact_link_function( pastcontact_link);
     document.getElementById('followup_dialogbox').style.display='none'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}
let past_contact_dialog='./images/demo3.png'

function pastcontact_link_function(imgtobesend)
{
    
    console.log('AskAssistance  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','pastconstct_link')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in pastconstct_link';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside pastconstct_link');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('pastconstct_link').style.display='none'
        pastcontact_dialog_function( past_contact_dialog);
    // past_contact_dialog
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let pastcontact_action1='./images/14_follow_up.png';
function pastcontact_dialog_function(imgtobesend)
{
    
    console.log('past_contact_dialog  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','pastccontact_dialog')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        pastcontact_action1_function( pastcontact_action1);
     document.getElementById('pastccontact_dialog').style.display='block'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}


let pastcontact_action1_followup='./images/addcontactinfobutton.png'
function pastcontact_action1_function(imgtobesend)
{
    
    console.log('pastcontact_action1_function  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','page13followup')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in page13followup';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside page13followup');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('page13followup').style.display='none'
        pastcontact_dialog_function_action1( pastcontact_action1_followup);
    // past_contact_dialog
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let transfer_button_link="./images/transfer_button.png";

function pastcontact_dialog_function_action1(imgtobesend)
{
    
    console.log('page14followup  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','page14followup')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        Trasnferlink( transfer_button_link);//transfer
     document.getElementById('page14followup').style.display='none'
     document.getElementById('page13followup').style.display='none'
    //  document.getElementById('action_button').style.display='none'
     document.getElementById('pastccontact_dialog').style.display='none'
    }
     
    )
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}


let start_transfer_link="./images/start_transfer.png" 
function Trasnferlink(imgtobesend)
{
    
    console.log('Trasnferlink()  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','transferbutton')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in pastconstct_link';


   
    aTag.addEventListener('click',()=>{
        // console.log('Inside transferbutton');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('transferbutton').style.display='none'
        starttransfer_function( start_transfer_link);
    // past_contact_dialog
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let start_button_transfer='./images/start_button_transfer.png'

function starttransfer_function(imgtobesend)
{
    
    console.log('starttransfer_function  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','start_button_transfer')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        // console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        confirmDialogtransferm( start_button_transfer);
     document.getElementById('start_button_transfer').style.display='block'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let confirmtransfrom="./images/consfirm_transform.png"

function confirmDialogtransferm(imgtobesend)
{
    
    console.log('confirmDialogtransferm  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','confirm_transform1')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        confirmtransform_dialog_box( confirmtransfrom);
     document.getElementById('confirm_transform1').style.display='none'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let yes_button="./images/yes_button_.png"
function confirmtransform_dialog_box(imgtobesend)
{
 
    console.log('confirm_transform  button');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','confirm_transform')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in yess_buttton';


   
    aTag.addEventListener('click',()=>{
        console.log('confirm_transform');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        yesbuttonClick( yes_button);
     document.getElementById('confirm_transform').style.display='block'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}


let complete_contact_summary_image="./images/complete_contact_summary.png"

function yesbuttonClick(imgtobesend)
{
    
    console.log('yes  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','yess_buttton')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in yess_buttton';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside yess_buttton');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('yess_buttton').style.display='none'
        document.getElementById('confirm_transform').style.display='none'
        document.getElementById('confirm_transform1').style.display='none'
        document.getElementById('start_button_transfer').style.display='none'
        
        
        call_complete_summary( complete_contact_summary_image);
    // past_contact_dialog
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let order_summary_link="./images/order_summary.png"
function  call_complete_summary(imagtosend)
{

    console.log('complete_contact_summary  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','complete_contact_summary')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imagtosend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='complete_contact_summary';


   
    aTag.addEventListener('click',()=>{
        
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        order_summary_link_followup( order_summary_link);
     document.getElementById('complete_contact_summary').style.display='block'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)
}
let order_summary_dialog="./images/order_summary_dialog.png"
function order_summary_link_followup(imgtobesend)
{
    
    console.log('Followup  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','order_summary')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('order_summary').style.display='none'
        document.getElementById('complete_contact_summary').style.display='block'
        
        order_summary_dialog_funct( order_summary_dialog);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

let callLink_button="./images/call_button.png" 

function order_summary_dialog_funct(imgtobesend)
{
    
    console.log('order_summary_dialog  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','order_summary_dialog')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        callbutton_link( callLink_button);
     document.getElementById('order_summary_dialog').style.display='none'
     
     document.getElementById('complete_contact_summary').style.display='none'
     
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}
let call_button_action2="./images/call_button_action2.png";
function callbutton_link(imgtobesend)
{
    
    console.log('callbuttom  Link');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.classList.add('highlight')
    card.setAttribute('id','resources')
    card.setAttribute('id','callbuttom')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside aTag');
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        document.getElementById('callbuttom').style.display='none'
        CallActiondialogfunction( call_button_action2);
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}



function CallActiondialogfunction(imgtobesend)
{
    
    console.log('callbuttom_action2  Dialog');
    let card=document.createElement('div')
    let id=document.createAttribute('id','lamo')
    card.classList.add('card')
    card.setAttribute('id','resources') 
    card.classList.add('highlight')
    card.setAttribute('id','callbuttom_action2')
    let img1=document.createElement('img')
    img1.classList.add('card-img-top')
    img1.src=imgtobesend;
    card.appendChild(img1);
    

    let card_body=document.createElement('div');
        card_body.setAttribute('id','visible11');
    var aTag = document.createElement('a');
    // aTag.setAttribute('href','./scr1.png')
    

    aTag.innerText = "Next"
    aTag.classList.add('btn')
    aTag.classList.add('btn-warning')
    card_body.appendChild(aTag);
    let p=document.createElement('p');
    p.textContent='Click in Ask A lead';


   
    aTag.addEventListener('click',()=>{
        console.log('Inside last');
        document.querySelector('.card').style.display='none'
        card_body.classList.add('disable1')
        card.classList.remove('card')
        card.classList.remove('highlight')
        // ask_assistance( ask_assistance_link);
     document.getElementById('callbuttom_action2').style.display='none'
    
    })
    card_body.appendChild(p)
    card.appendChild(card_body)
    // card.appendChild(p)
    maindiv.appendChild(card)
// document.body.append(card)

}

